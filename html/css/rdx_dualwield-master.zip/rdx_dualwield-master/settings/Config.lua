Config = {} 

Config.AutoDualWield = true

