# RDX-Core
## rdx_dualwield
main_cl code by Disguise this is just v0.1 a menu and much more to come.


## 1 Install
add rdx_dualwield to your Server /resouces folder

## 2 Server.Cfg
start rdx_dualweield

## 3 Configs.lua
Config.AutoDualwield = true

version 0.1
TODO: Menu, tables, make dual wield a quest
