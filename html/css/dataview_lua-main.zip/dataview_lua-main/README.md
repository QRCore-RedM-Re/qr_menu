# dataview_lua

Just a simple edit to the Dataview script from femga/rdr3discoveries (https://github.com/femga/rdr3_discoveries/blob/master/AI/EVENTS/dataview_by_Gottfriedleibniz.lua)

make sure to add this line to fxmanifest under client scripts for any scripts you have that use dataview:
- '@dataview_lua/client.lua'
  
credits to femga and Gottfriedleibniz
